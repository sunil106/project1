package com.niit.shoppingcart.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller  ///
@RequestMapping("/niit")
public class TestController {
	
	
@RequestMapping("/sunil")
public String test()
{
		return "sunil";
}
}
